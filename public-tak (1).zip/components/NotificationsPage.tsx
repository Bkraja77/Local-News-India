
import React, { useState, useEffect } from 'react';
import Header from './Header';
import { db } from '../firebaseConfig';
import { User, Notification } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import ConfirmationModal from './ConfirmationModal';

interface NotificationsPageProps {
  onBack: () => void;
  currentUser: User | null;
  onViewPost: (postId: string) => void;
}

const SkeletonNotification = () => (
  <div className="p-4 md:p-5 flex items-center gap-4 animate-pulse border-b border-gray-50">
    <div className="w-12 h-12 rounded-full bg-gray-200 flex-shrink-0"></div>
    <div className="flex-1 space-y-2">
      <div className="h-4 w-3/4 bg-gray-200 rounded"></div>
      <div className="h-3 w-1/4 bg-gray-200 rounded"></div>
    </div>
  </div>
);

const NotificationsPage: React.FC<NotificationsPageProps> = ({ onBack, currentUser, onViewPost }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [isClearModalOpen, setIsClearModalOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  
  const { t } = useLanguage();
  const { showToast } = useToast();

  useEffect(() => {
    if (!currentUser) {
      setLoading(false);
      return;
    }

    const unsubscribe = db.collection('users')
      .doc(currentUser.uid)
      .collection('notifications')
      .orderBy('createdAt', 'desc')
      .limit(50)
      .onSnapshot(snapshot => {
        const fetchedNotifications = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
          createdAt: doc.data().createdAt?.toDate() || new Date(),
        } as Notification));
        setNotifications(fetchedNotifications);
        setLoading(false);
      }, error => {
        console.error("Error fetching notifications:", error);
        setLoading(false);
      });

    return () => unsubscribe();
  }, [currentUser]);

  const handleNotificationClick = async (notification: Notification) => {
    if (!currentUser) return;

    // Mark as read
    if (!notification.read) {
      try {
        await db.collection('users')
          .doc(currentUser.uid)
          .collection('notifications')
          .doc(notification.id)
          .update({ read: true });
      } catch (error) {
        console.error("Error marking notification as read:", error);
      }
    }

    // Navigate if applicable
    if (notification.postId) {
      onViewPost(notification.postId);
    }
  };

  const handleDeleteOne = async (e: React.MouseEvent, notificationId: string) => {
    e.stopPropagation(); // Prevent navigation
    if (!currentUser) return;

    try {
        await db.collection('users')
            .doc(currentUser.uid)
            .collection('notifications')
            .doc(notificationId)
            .delete();
        showToast("Notification removed", "success");
    } catch (error) {
        console.error("Error deleting notification:", error);
        showToast("Failed to delete notification", "error");
    }
  };

  const handleClearAll = async () => {
      if (!currentUser || notifications.length === 0) return;
      setIsDeleting(true);
      
      try {
          const batch = db.batch();
          notifications.forEach(notif => {
              const ref = db.collection('users').doc(currentUser.uid).collection('notifications').doc(notif.id);
              batch.delete(ref);
          });
          
          await batch.commit();
          showToast("All notifications cleared", "success");
      } catch (error) {
          console.error("Error clearing notifications:", error);
          showToast("Failed to clear notifications", "error");
      } finally {
          setIsDeleting(false);
          setIsClearModalOpen(false);
      }
  };

  const timeAgo = (date: Date) => {
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (seconds < 60) return 'Just now';
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d ago`;
    return date.toLocaleDateString();
  };

  const getNotificationText = (notification: Notification) => {
    switch (notification.type) {
      case 'new_like':
        return `liked your post "${notification.postTitle || 'Untitled'}"`;
      case 'new_comment':
        return `commented on your post "${notification.postTitle || 'Untitled'}"`;
      case 'new_follower':
        return `started following you`;
      case 'new_post':
        return `published a new post "${notification.postTitle || 'Untitled'}"`;
      default:
        return 'interacted with you';
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'new_like': return 'favorite';
      case 'new_comment': return 'chat_bubble';
      case 'new_follower': return 'person_add';
      case 'new_post': return 'article';
      default: return 'notifications';
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case 'new_like': return 'text-red-500 bg-red-50';
      case 'new_comment': return 'text-blue-500 bg-blue-50';
      case 'new_follower': return 'text-green-500 bg-green-50';
      case 'new_post': return 'text-purple-500 bg-purple-50';
      default: return 'text-gray-500 bg-gray-50';
    }
  };

  return (
    <div className="flex flex-col h-full bg-transparent">
      <Header title={t('notifications')} showBackButton onBack={onBack} />
      <main className="flex-grow overflow-y-auto p-0 md:p-6 pb-20">
        <div className="w-full">
          {!currentUser ? (
            <div className="flex flex-col items-center justify-center h-[60vh] text-gray-500">
              <span className="material-symbols-outlined text-6xl mb-4 text-gray-300">lock</span>
              <p className="text-lg font-medium">Please log in to see notifications.</p>
            </div>
          ) : loading ? (
            <div className="glass-card overflow-hidden w-full divide-y divide-gray-100">
              {[...Array(8)].map((_, i) => <SkeletonNotification key={i} />)}
            </div>
          ) : notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-[60vh] text-gray-500">
              <span className="material-symbols-outlined text-8xl text-gray-200 mb-6">notifications_off</span>
              <p className="text-xl font-medium text-gray-600">No notifications yet.</p>
              <p className="text-sm mt-2 text-gray-400">We'll let you know when something happens.</p>
            </div>
          ) : (
            <div className="w-full space-y-4">
                {/* Clear All Button */}
                <div className="flex justify-end px-4 md:px-0">
                    <button 
                        onClick={() => setIsClearModalOpen(true)}
                        className="text-xs font-bold text-red-600 hover:text-red-700 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-full transition-colors flex items-center gap-1"
                    >
                        <span className="material-symbols-outlined text-sm">delete_sweep</span>
                        Clear All
                    </button>
                </div>

                <div className="glass-card overflow-hidden w-full">
                <div className="divide-y divide-gray-100">
                    {notifications.map(notification => (
                    <div 
                        key={notification.id}
                        onClick={() => handleNotificationClick(notification)}
                        className={`p-4 md:p-5 flex items-center gap-4 cursor-pointer transition-all hover:bg-gray-50 group relative ${!notification.read ? 'bg-blue-50/60 border-l-4 border-blue-500' : 'border-l-4 border-transparent'}`}
                    >
                        <div className="relative flex-shrink-0">
                        <img 
                            src={notification.fromUserProfilePicUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${notification.fromUserName}`} 
                            alt={notification.fromUserName}
                            className="w-12 h-12 rounded-full object-cover border border-gray-200 shadow-sm"
                        />
                        <div className={`absolute -bottom-1 -right-1 rounded-full p-1 border-2 border-white shadow-sm ${getIconColor(notification.type)}`}>
                            <span className="material-symbols-outlined text-[14px] block">{getIcon(notification.type)}</span>
                        </div>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                        <p className="text-base text-gray-800 leading-snug pr-6">
                            <span className="font-bold hover:underline hover:text-blue-600 transition-colors">{notification.fromUserName}</span> {getNotificationText(notification)}
                        </p>
                        <p className="text-xs text-gray-500 mt-1.5 flex items-center gap-1">
                            <span className="material-symbols-outlined text-[14px]">schedule</span>
                            {timeAgo(notification.createdAt)}
                        </p>
                        </div>
                        
                        <div className="flex items-center gap-2 flex-shrink-0">
                            {!notification.read && (
                                <div className="w-2.5 h-2.5 rounded-full bg-blue-500 shadow-sm animate-pulse"></div>
                            )}
                            
                            <button 
                                onClick={(e) => handleDeleteOne(e, notification.id)}
                                className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-full transition-colors md:opacity-0 md:group-hover:opacity-100"
                                title="Delete Notification"
                            >
                                <span className="material-symbols-outlined text-lg">delete</span>
                            </button>
                        </div>
                    </div>
                    ))}
                </div>
                </div>
            </div>
          )}
        </div>
      </main>

      <ConfirmationModal 
        isOpen={isClearModalOpen}
        onClose={() => setIsClearModalOpen(false)}
        onConfirm={handleClearAll}
        title="Clear Notifications"
        message="Are you sure you want to delete all notifications? This action cannot be undone."
        confirmButtonText={isDeleting ? "Clearing..." : "Clear All"}
        confirmButtonColor="bg-red-600 hover:bg-red-700"
      />
    </div>
  );
};

export default NotificationsPage;
