
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Post, User, View, Comment } from '../types';
import Header from './Header';
import { db, serverTimestamp, increment, storage } from '../firebaseConfig';
import ReportModal from './ReportModal';
import { useLanguage } from '../contexts/LanguageContext';
import { useToast } from '../contexts/ToastContext';
import ConfirmationModal from './ConfirmationModal';
import AdBanner from './AdBanner';
import { languages } from '../utils/translations';
import { GoogleGenAI } from "@google/genai";

interface PostDetailPageProps {
    postId: string;
    currentUser: User | null;
    onBack: () => void;
    onLogin: () => void;
    onNavigate: (view: View) => void;
    onViewUser: (userId: string) => void;
    onViewPost: (postId: string) => void;
    onEditPost: (postId: string) => void;
}

interface Reply {
    id: string;
    content: string;
    authorId: string;
    authorName: string;
    authorProfilePicUrl: string;
    createdAt: Date;
}

// --- Audio Helper Functions ---
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

// --- Inner Component: Comment Item ---
const CommentItem: React.FC<{
    comment: Comment;
    postId: string;
    currentUser: User | null;
    isPostAuthor: boolean;
    isAdmin: boolean;
    onViewUser: (id: string) => void;
    onDelete: (id: string) => void;
    onLogin: () => void;
    showToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}> = ({ comment, postId, currentUser, isPostAuthor, isAdmin, onViewUser, onDelete, onLogin, showToast }) => {
    // Local state
    const [isLiked, setIsLiked] = useState(false);
    const [likeCount, setLikeCount] = useState(0);
    const [isReplying, setIsReplying] = useState(false);
    const [replyText, setReplyText] = useState('');
    const [isSubmittingReply, setIsSubmittingReply] = useState(false);
    
    // State for replies from Server (DB)
    const [serverReplies, setServerReplies] = useState<Reply[]>([]);
    // Optimistic replies (temporary)
    const [localReplies, setLocalReplies] = useState<Reply[]>([]);

    // Merge server and local replies for display
    const displayReplies = useMemo(() => {
        // Combine arrays
        const combined = [...serverReplies, ...localReplies];
        
        // Remove duplicates based on ID
        const uniqueIds = new Set();
        const uniqueReplies = combined.filter(item => {
            if (!uniqueIds.has(item.id)) {
                uniqueIds.add(item.id);
                return true;
            }
            return false;
        });

        // Sort ascending (Oldest at top, Newest at bottom)
        return uniqueReplies.sort((a, b) => {
            const timeA = a.createdAt ? a.createdAt.getTime() : 0;
            const timeB = b.createdAt ? b.createdAt.getTime() : 0;
            return timeA - timeB;
        });
    }, [serverReplies, localReplies]);

    // 1. Real-time listener for COMMENT LIKES
    useEffect(() => {
        if (!comment.id || !postId) return;
        
        const likesCollRef = db.collection('posts').doc(postId).collection('comments').doc(comment.id).collection('likes');
        
        const unsubscribe = likesCollRef.onSnapshot(snapshot => {
            setLikeCount(snapshot.size);
            if (currentUser) {
                // Check if the current user's ID exists as a document ID
                // Rule: match /likes/{userId}
                const userLiked = snapshot.docs.some(doc => doc.id === currentUser.uid);
                setIsLiked(userLiked);
            } else {
                setIsLiked(false);
            }
        }, error => {
            console.warn("Error fetching comment likes:", error);
        });
        
        return () => unsubscribe();
    }, [postId, comment.id, currentUser]);

    // 2. Real-time listener for COMMENT REPLIES
    useEffect(() => {
        if (!comment.id || !postId) return;

        // Fetch collection without orderBy initially to prevent index errors.
        // We sort client-side in useMemo.
        const repliesCollRef = db.collection('posts').doc(postId).collection('comments').doc(comment.id).collection('replies');
        
        const unsubscribe = repliesCollRef.onSnapshot(snapshot => {
            const fetchedReplies = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    ...data,
                    // Handle serverTimestamp being null immediately after write
                    createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date() 
                } as Reply;
            });
            
            setServerReplies(fetchedReplies);
            
            // Clean up local optimistic replies that are now present in server data
            setLocalReplies(prev => prev.filter(local => !fetchedReplies.some(server => 
                // Fuzzy match to identify the same reply
                server.authorId === local.authorId && 
                server.content === local.content
            )));

        }, error => {
            console.error("Error fetching replies:", error);
        });

        return () => unsubscribe();
    }, [postId, comment.id]);

    const handleLike = async () => {
        if (!currentUser) {
            showToast("Please log in to like comments.", "info");
            onLogin();
            return;
        }

        // Optimistic UI Update
        const previousIsLiked = isLiked;
        
        setIsLiked(!previousIsLiked);
        setLikeCount(prev => previousIsLiked ? prev - 1 : prev + 1);

        try {
            // The document ID is the userID. Matches rule: match /likes/{userId}
            const likeDocRef = db.collection('posts').doc(postId)
                .collection('comments').doc(comment.id)
                .collection('likes').doc(currentUser.uid);

            if (previousIsLiked) {
                await likeDocRef.delete();
            } else {
                await likeDocRef.set({
                    likedAt: serverTimestamp(),
                    userId: currentUser.uid
                });
            }
        } catch (error: any) {
            console.error("Like action failed:", error);
            // Revert on error
            setIsLiked(previousIsLiked);
            setLikeCount(prev => previousIsLiked ? prev + 1 : prev - 1);
            showToast(`Action failed: ${error.message || "Check connection"}`, "error");
        }
    };

    const handleReplySubmit = async () => {
        if (!replyText.trim()) return;
        if (!currentUser) {
            onLogin();
            return;
        }
        // Allowed all users to reply

        const textToSend = replyText.trim();
        setIsSubmittingReply(true);

        // Optimistic UI: Show immediately
        const tempId = 'local-' + Date.now();
        const newReply: Reply = {
            id: tempId,
            content: textToSend,
            authorId: currentUser.uid,
            authorName: currentUser.name || 'User',
            authorProfilePicUrl: currentUser.profilePicUrl || '',
            createdAt: new Date()
        };
        
        setLocalReplies(prev => [...prev, newReply]);
        setIsReplying(false);
        setReplyText('');

        try {
            const repliesCollRef = db.collection('posts').doc(postId).collection('comments').doc(comment.id).collection('replies');
            
            const replyData = {
                content: textToSend,
                authorId: currentUser.uid, 
                authorName: currentUser.name || 'User',
                authorProfilePicUrl: currentUser.profilePicUrl || '',
                createdAt: serverTimestamp()
            };

            // Rule: request.resource.data.authorId == request.auth.uid
            await repliesCollRef.add(replyData);
            
        } catch (error: any) {
            console.error("Error replying:", error);
            // Remove the optimistic reply if it failed
            setLocalReplies(prev => prev.filter(r => r.id !== tempId));
            showToast(`Failed to reply: ${error.message || "Check connection"}`, "error");
        } finally {
            setIsSubmittingReply(false);
        }
    };

    const handleDeleteReply = async (replyId: string) => {
        if(!currentUser) return;
        if(window.confirm("Delete this reply?")) {
             try {
                // Rule allows delete if isOwner(resource.data.authorId) || isAdmin()
                await db.collection('posts').doc(postId)
                    .collection('comments').doc(comment.id)
                    .collection('replies').doc(replyId).delete();
                showToast("Reply deleted.", "success");
             } catch (error: any) {
                 console.error("Error deleting reply:", error);
                 showToast(`Could not delete: ${error.message}`, "error");
             }
        }
    };

    const timeAgo = (date: Date | null | undefined) => {
        if (!date) return 'Just now';
        const now = new Date();
        const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
        if (seconds < 60) return 'Just now';
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes}m`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours}h`;
        const days = Math.floor(hours / 24);
        return `${days}d`;
    };

    const isCurrentUserComment = currentUser && currentUser.uid === comment.authorId;

    return (
        <div className="flex items-start gap-3 group">
            <img 
                src={comment.authorProfilePicUrl || "https://api.dicebear.com/8.x/initials/svg?seed=User"} 
                alt={comment.authorName} 
                className="w-9 h-9 rounded-full object-cover cursor-pointer ring-2 ring-transparent group-hover:ring-gray-100 transition-all flex-shrink-0" 
                onClick={() => onViewUser(comment.authorId)} 
            />
            <div className="flex-grow min-w-0">
                {/* Main Comment Bubble */}
                <div className="bg-gray-50 rounded-2xl rounded-tl-none p-3.5 relative border border-transparent hover:border-gray-100 transition-all">
                    <div className="flex justify-between items-center mb-1">
                        <p className="font-bold text-sm text-gray-900 cursor-pointer hover:text-blue-600 truncate" onClick={() => onViewUser(comment.authorId)}>
                            {comment.authorName}
                        </p>
                        <span className="text-[10px] text-gray-400 font-medium">{timeAgo(comment.createdAt)}</span>
                    </div>
                    <p className="text-gray-800 text-sm leading-relaxed break-words whitespace-pre-wrap">{comment.content}</p>
                    
                    {(isAdmin || isCurrentUserComment) && (
                        <button 
                            onClick={() => onDelete(comment.id)} 
                            className={`absolute top-2 right-2 text-gray-400 hover:text-red-600 p-1 rounded-full hover:bg-red-50 transition-colors ${isAdmin ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}
                            title="Delete Comment"
                        >
                            <span className="material-symbols-outlined text-base">delete</span>
                        </button>
                    )}
                </div>

                {/* Actions Row */}
                <div className="flex items-center gap-4 mt-1.5 ml-2">
                    <button 
                        onClick={handleLike} 
                        className={`flex items-center gap-1 text-xs font-semibold transition-all active:scale-90 ${isLiked ? 'text-red-600' : 'text-gray-500 hover:text-red-500'}`}
                    >
                        <span 
                            className={`material-symbols-outlined text-[16px] transition-transform ${isLiked ? 'scale-110' : ''}`} 
                            style={{ fontVariationSettings: `'FILL' ${isLiked ? 1 : 0}, 'wght' 400` }}
                        >
                            favorite
                        </span>
                        {likeCount > 0 ? likeCount : 'Like'}
                    </button>

                    {/* Allow replying if logged in */}
                    {currentUser && !isReplying && (
                        <button 
                            onClick={() => setIsReplying(true)}
                            className="text-xs font-semibold text-gray-500 hover:text-blue-600 transition-colors flex items-center gap-1"
                        >
                            <span className="material-symbols-outlined text-[16px]">reply</span>
                            Reply
                        </button>
                    )}
                </div>

                {/* Reply Input Form */}
                {isReplying && (
                    <div className="mt-3 ml-2">
                        <div className="flex gap-2">
                            <div className="w-0.5 bg-gray-200 rounded-full"></div>
                            <div className="flex-grow">
                                <textarea 
                                    value={replyText}
                                    onChange={(e) => setReplyText(e.target.value)}
                                    placeholder="Write a reply..."
                                    className="w-full p-3 text-sm border border-blue-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 bg-blue-50/30"
                                    rows={2}
                                    autoFocus
                                />
                                <div className="flex justify-end gap-2 mt-2">
                                    <button 
                                        onClick={() => setIsReplying(false)}
                                        className="px-3 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                                    >
                                        Cancel
                                    </button>
                                    <button 
                                        onClick={handleReplySubmit}
                                        disabled={isSubmittingReply || !replyText.trim()}
                                        className="px-4 py-1.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-lg disabled:opacity-50 shadow-sm transition-all active:scale-95"
                                    >
                                        {isSubmittingReply ? 'Sending...' : 'Post Reply'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Display Replies */}
                {displayReplies.length > 0 && (
                    <div className="mt-2 ml-2 flex flex-col gap-2">
                        {displayReplies.map(reply => (
                            <div key={reply.id} className="flex gap-3 group/reply">
                                <div className="flex flex-col items-center">
                                     <div className="w-0.5 h-4 bg-gray-200 rounded-full mb-1"></div> {/* Connector line */}
                                     <img 
                                        src={reply.authorProfilePicUrl || "https://api.dicebear.com/8.x/initials/svg?seed=User"} 
                                        className="w-6 h-6 rounded-full object-cover ring-2 ring-blue-600 shadow-sm" 
                                        alt="Author" 
                                     />
                                </div>
                                <div className="bg-gradient-to-br from-blue-50 to-white border border-blue-100 rounded-2xl rounded-tl-none p-3 flex-grow shadow-sm relative">
                                    <div className="flex items-center justify-between mb-1">
                                        <div className="flex items-center gap-2">
                                            {/* Highlight if reply is from post author */}
                                            {reply.authorId === isPostAuthor ? (
                                                <span className="bg-blue-600 text-white text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider flex items-center gap-1">
                                                    <span className="material-symbols-outlined text-[10px]">verified</span>
                                                    Author
                                                </span>
                                            ) : (
                                                <span className="font-bold text-xs text-gray-800">{reply.authorName}</span>
                                            )}
                                            {reply.createdAt && <span className="text-[10px] text-gray-400">{timeAgo(reply.createdAt)}</span>}
                                        </div>
                                        {/* Delete Reply Button (for owner or admin) */}
                                        {(isAdmin || (currentUser && currentUser.uid === reply.authorId)) && (
                                            <button 
                                                onClick={() => handleDeleteReply(reply.id)}
                                                className="opacity-0 group-hover/reply:opacity-100 text-gray-400 hover:text-red-500 transition-opacity p-1"
                                                title="Delete Reply"
                                            >
                                                <span className="material-symbols-outlined text-sm">delete</span>
                                            </button>
                                        )}
                                    </div>
                                    <p className="text-sm text-gray-800 font-medium">{reply.content}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};


// --- Main PostDetailPage ---

// Skeleton Loader for Post Detail
const SkeletonPostDetail = () => (
    <div className="flex flex-col h-full bg-transparent animate-pulse">
        <div className="h-14 bg-white border-b border-gray-200"></div> {/* Header */}
        <div className="flex-grow overflow-y-auto pb-20 md:pb-10">
            <div className="w-full max-w-7xl mx-auto md:px-4 lg:px-8 py-0 md:py-6">
                <div className="bg-white my-4 rounded-2xl shadow-sm h-[80vh] flex flex-col border border-gray-100">
                    <div className="px-6 py-4 flex items-center gap-3 border-b border-gray-100">
                        <div className="w-10 h-10 rounded-full bg-gray-200"></div>
                        <div className="flex-1 space-y-2">
                            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
                            <div className="h-3 bg-gray-200 rounded w-1/6"></div>
                        </div>
                    </div>
                    <div className="w-full h-64 bg-gray-200"></div>
                    <div className="p-12 space-y-6">
                        <div className="h-8 bg-gray-200 rounded w-3/4"></div>
                        <div className="space-y-3">
                            <div className="h-4 bg-gray-200 rounded w-full"></div>
                            <div className="h-4 bg-gray-200 rounded w-full"></div>
                            <div className="h-4 bg-gray-200 rounded w-5/6"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
);

const PostDetailPage: React.FC<PostDetailPageProps> = ({ postId, currentUser, onBack, onLogin, onNavigate, onViewUser, onViewPost, onEditPost }) => {
    const [post, setPost] = useState<Post | null>(null);
    const [comments, setComments] = useState<Comment[]>([]);
    const [newComment, setNewComment] = useState('');
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isSubmittingComment, setIsSubmittingComment] = useState(false);
    
    const [likeCount, setLikeCount] = useState(0);
    const [isLiked, setIsLiked] = useState(false);
    const [isFollowing, setIsFollowing] = useState(false);

    const [relatedPosts, setRelatedPosts] = useState<Post[]>([]);

    const [isReportModalOpen, setIsReportModalOpen] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const [isDeletePostModalOpen, setIsDeletePostModalOpen] = useState(false);
    const [isDeleteCommentModalOpen, setIsDeleteCommentModalOpen] = useState(false);
    const [commentToDeleteId, setCommentToDeleteId] = useState<string | null>(null);

    // Translation State
    const [translatedData, setTranslatedData] = useState<{ title: string; content: string } | null>(null);
    const [isTranslating, setIsTranslating] = useState(false);
    const [showTranslateMenu, setShowTranslateMenu] = useState(false);
    const translateMenuRef = useRef<HTMLDivElement>(null);

    // Audio / Text-to-Speech State
    const [isPlayingAudio, setIsPlayingAudio] = useState(false);
    const [isGeneratingAudio, setIsGeneratingAudio] = useState(false);
    const audioContextRef = useRef<AudioContext | null>(null);
    const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

    // Ref to track view increment to avoid duplicates in strict mode or re-renders
    const lastIncrementedPostId = useRef<string | null>(null);

    const { t } = useLanguage();
    const { showToast } = useToast();

    // Effect to increment view count
    useEffect(() => {
        // Check if we already incremented for this specific postId
        if (postId && lastIncrementedPostId.current !== postId) {
            lastIncrementedPostId.current = postId;
            
            const postRef = db.collection('posts').doc(postId);
            postRef.update({
                viewCount: increment(1)
            }).catch(err => {
                // Fail silently or log warn, don't disrupt user
                console.warn(`Could not update view count. Error: ${err.message}`);
            });
        }
    }, [postId]);

    useEffect(() => {
        let unsubPost: () => void = () => {};
        let unsubComments: () => void = () => {};
        let unsubLikes: () => void = () => {};
        let unsubIsFollowing: () => void = () => {};
        
        setPost(null);
        setRelatedPosts([]);
        setLoading(true);
        setError(null);
        setTranslatedData(null); // Reset translation on new post load
        stopAudio(); // Stop any playing audio

        const postRef = db.collection('posts').doc(postId);
        unsubPost = postRef.onSnapshot(docSnap => {
            if (docSnap.exists) {
                const postData = docSnap.data();
                const fetchedPost = {
                    id: docSnap.id,
                    ...postData,
                    category: postData.category || 'General',
                    createdAt: postData.createdAt?.toDate() || null,
                    locationType: postData.locationType || 'Overall',
                    state: postData.state || '',
                    district: postData.district || '',
                    block: postData.block || '',
                } as Post;
                setPost(fetchedPost);
                
                document.title = `${fetchedPost.title} - Public Tak`;

                if (currentUser && currentUser.uid !== fetchedPost.authorId) {
                    const isFollowingRef = db.collection('users').doc(currentUser.uid).collection('following').doc(fetchedPost.authorId);
                    unsubIsFollowing = isFollowingRef.onSnapshot((doc) => {
                        setIsFollowing(doc.exists);
                    });
                }
            } else {
                setError("Post not found.");
            }
            setLoading(false);
        }, err => {
            setError("Failed to load post.");
            setLoading(false);
        });

        // Fetch Comments - Sort client side for robustness
        const commentsQuery = db.collection('posts').doc(postId).collection('comments');
        unsubComments = commentsQuery.onSnapshot(snapshot => {
            const fetchedComments = snapshot.docs.map(doc => ({
                id: doc.id,
                ...doc.data(),
                content: doc.data().content,
                createdAt: doc.data().createdAt?.toDate() || new Date(),
            } as Comment));
            
            // Newest first
            fetchedComments.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
            setComments(fetchedComments);
        });
        
        const likesRef = db.collection('posts').doc(postId).collection('likes');
        unsubLikes = likesRef.onSnapshot((snapshot) => {
            setLikeCount(snapshot.size);
            if (currentUser) {
                setIsLiked(snapshot.docs.some(doc => doc.id === currentUser.uid));
            } else {
                setIsLiked(false);
            }
        });

        return () => {
            unsubPost();
            unsubComments();
            unsubLikes();
            unsubIsFollowing();
            stopAudio(); // Ensure audio stops on unmount
            document.title = "Public Tak";
        };
    }, [postId, currentUser]);

    // Close translate menu on click outside
    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (translateMenuRef.current && !translateMenuRef.current.contains(event.target as Node)) {
                setShowTranslateMenu(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    // Fetch related posts
    useEffect(() => {
        if (!post) return;

        const fetchRelatedPosts = async () => {
            try {
                const query = db.collection('posts')
                                .where('category', '==', post.category)
                                .limit(10);

                const snapshot = await query.get();
                const candidates = snapshot.docs
                    .map(doc => {
                        const data = doc.data();
                        return { 
                            id: doc.id,
                            ...data,
                            createdAt: data.createdAt?.toDate() || null,
                         } as Post
                    })
                    .filter(p => p.id !== post.id);

                const scoredPosts = candidates.map(candidate => {
                    let score = 0;
                    if (candidate.category === post.category) score += 3;
                    if (post.state && candidate.state === post.state) score += 2;
                    if (post.district && candidate.district === post.district) score += 1;
                    if (candidate.authorId === post.authorId) score += 1;
                    return { ...candidate, score };
                });

                scoredPosts.sort((a, b) => b.score - a.score);
                setRelatedPosts(scoredPosts.slice(0, 3));
            } catch (err) {
                console.error("Error fetching related posts:", err);
            }
        };

        fetchRelatedPosts();
    }, [post]);


    const handleCommentSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!currentUser) {
            showToast("Please log in to comment.", "info");
            onLogin();
            return;
        }
        const trimmedComment = newComment.trim();
        if (!trimmedComment) return;

        if (trimmedComment.length > 1000) {
            showToast("Comment exceeds 1000 characters limit.", "error");
            return;
        }

        setIsSubmittingComment(true);
        try {
            const commentsRef = db.collection('posts').doc(postId).collection('comments');
            const batch = db.batch();

            const commentDocRef = commentsRef.doc();
            
            const commentData = {
                content: trimmedComment,
                postId: postId,
                authorId: currentUser.uid,
                userId: currentUser.uid, 
                authorName: currentUser.name || 'User',
                authorProfilePicUrl: currentUser.profilePicUrl || '',
                createdAt: serverTimestamp(),
                likeCount: 0
            };

            batch.set(commentDocRef, commentData);
            
            if (post && currentUser.uid !== post.authorId) {
                const notificationRef = db.collection('users').doc(post.authorId).collection('notifications').doc();
                const notifData = {
                    type: 'new_comment',
                    fromUserId: currentUser.uid,
                    fromUserName: currentUser.name || 'User',
                    fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                    postId: postId,
                    postTitle: post.title || 'Post',
                    createdAt: serverTimestamp(),
                    read: false
                };
                batch.set(notificationRef, notifData);
            }

            await batch.commit();
            setNewComment('');
            showToast("Comment posted!", "success");
        } catch (error: any) {
            console.error("Error submitting comment:", error);
            showToast(`Failed to post comment: ${error.message}`, "error");
        } finally {
            setIsSubmittingComment(false);
        }
    };
    
    const handleLike = async () => {
        if (!currentUser || !post) {
            showToast("Please log in to like posts.", "info");
            onLogin();
            return;
        }

        // Optimistic update
        const prevIsLiked = isLiked;
        setIsLiked(!prevIsLiked);
        setLikeCount(prev => prevIsLiked ? prev - 1 : prev + 1);

        const likeRef = db.collection('posts').doc(postId).collection('likes').doc(currentUser.uid);
        try {
            if (prevIsLiked) {
                await likeRef.delete();
            } else {
                const batch = db.batch();
                // Matches rules: match /likes/{userId}
                const likeData = { 
                    likedAt: serverTimestamp(),
                    userId: currentUser.uid
                };
                batch.set(likeRef, likeData);
                
                if (currentUser.uid !== post.authorId) {
                    const notificationRef = db.collection('users').doc(post.authorId).collection('notifications').doc();
                    const notifData = {
                        type: 'new_like',
                        fromUserId: currentUser.uid,
                        fromUserName: currentUser.name || 'User',
                        fromUserProfilePicUrl: currentUser.profilePicUrl || '',
                        postId: post.id,
                        postTitle: post.title || 'Post',
                        createdAt: serverTimestamp(),
                        read: false
                    };
                    batch.set(notificationRef, notifData);
                }
                await batch.commit();
            }
        } catch (error: any) {
            // Revert if failed
            setIsLiked(prevIsLiked);
            setLikeCount(prev => prevIsLiked ? prev + 1 : prev - 1);
            console.error("Error liking post:", error);
            showToast(`Could not like post: ${error.message}`, "error");
        }
    };

    const handleShare = async () => {
        if (!post) return;

        const baseUrl = window.location.origin;
        const shareUrl = `${baseUrl}?postId=${post.id}`;
        
        // Use translated content if available, else original
        const contentToShare = translatedData ? translatedData.content : post.content;
        const titleToShare = translatedData ? translatedData.title : post.title;
        
        const plainTextContent = contentToShare.replace(/<[^>]*>?/gm, '').replace(/\n/g, ' ');
        const shareSnippet = plainTextContent.substring(0, 100);
        
        const shareText = `*${titleToShare}*\n\n${shareSnippet}...\n\nRead full story here:\n${shareUrl}`;

        db.collection('posts').doc(post.id).update({ shareCount: increment(1) }).catch(console.error);

        const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;
        window.open(whatsappUrl, '_blank');
    };

    const handleFollowToggle = async () => {
        if (!currentUser || !post) {
            onLogin();
            return;
        }
        
        // Optimistic UI
        const prevFollowing = isFollowing;
        setIsFollowing(!prevFollowing);

        const currentUserRef = db.collection('users').doc(currentUser.uid);
        const targetUserRef = db.collection('users').doc(post.authorId);
        const followingRef = currentUserRef.collection('following').doc(post.authorId);
        const followerRef = targetUserRef.collection('followers').doc(currentUser.uid);

        try {
            const batch = db.batch();
            if (prevFollowing) {
                batch.delete(followingRef);
                batch.delete(followerRef);
            } else {
                batch.set(followingRef, { followedAt: serverTimestamp() });
                batch.set(followerRef, { followedAt: serverTimestamp() });

                const notificationRef = targetUserRef.collection('notifications').doc();
                const notifData = {
                    type: 'new_follower',
                    fromUserId: currentUser.uid,
                    fromUserName: currentUser.name || 'User',
                    fromUserProfilePicUrl: currentUser.profilePicUrl,
                    createdAt: serverTimestamp(),
                    read: false
                };
                batch.set(notificationRef, notifData);
            }
            await batch.commit();
        } catch (error: any) {
            setIsFollowing(prevFollowing); // Revert
            console.error("Error following/unfollowing user:", error);
            showToast(`Action failed: ${error.message}`, "error");
        }
    };

    const handleReport = () => {
        if (!currentUser) {
            showToast("You must be logged in to report a post.", "error");
            onLogin();
            return;
        }
        setIsReportModalOpen(true);
    };

    const handleReportSuccess = () => {
        setIsReportModalOpen(false);
    };

    const handleDeletePost = async () => {
        if (!post) return;
        try {
            // 1. Delete Firestore Document (Priority)
            await db.collection("posts").doc(post.id).delete();
            
            // 2. Try to delete Storage Image (Best Effort)
            if (post.thumbnailUrl && post.thumbnailUrl.includes('firebasestorage.googleapis.com')) {
                try {
                    const storageRef = storage.refFromURL(post.thumbnailUrl);
                    await storageRef.delete();
                } catch (storageErr) {
                    console.warn("Post deleted but thumbnail image cleanup failed (likely permission):", storageErr);
                }
            }
            showToast("Post deleted successfully.", "success");
            onBack();
        } catch (error: any) {
            console.error("Error deleting post:", error);
            showToast(`Failed to delete post: ${error.message || "Unknown error"}`, "error");
        } finally {
            setIsDeletePostModalOpen(false);
        }
    };

    const handleDeleteComment = async () => {
        if (!commentToDeleteId) return;
        try {
            await db.collection('posts').doc(postId).collection('comments').doc(commentToDeleteId).delete();
            showToast("Comment deleted.", "success");
        } catch (error) {
            console.error("Error deleting comment:", error);
            showToast("Failed to delete comment.", "error");
        } finally {
            setIsDeleteCommentModalOpen(false);
            setCommentToDeleteId(null);
        }
    };

    const confirmDeleteComment = (commentId: string) => {
        setCommentToDeleteId(commentId);
        setIsDeleteCommentModalOpen(true);
    };

    // --- Translation Logic ---
    const handleTranslate = async (targetLangName: string) => {
        if (!post) return;
        setIsTranslating(true);
        setShowTranslateMenu(false);
        stopAudio(); // Stop audio if playing when translating

        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            // Strip basic HTML for token efficiency but ask for HTML structure back
            const prompt = `Translate the following news article title and HTML content into ${targetLangName}. 
            Maintain the original HTML structure/formatting where possible (like <p>, <br>). 
            Return the response in this valid JSON format: 
            { "title": "Translated Title", "content": "Translated HTML Content" }
            
            Original Title: "${post.title}"
            Original Content: "${post.content.replace(/"/g, '\\"')}"`;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: "application/json"
                }
            });

            const resultText = response.text;
            if (resultText) {
                const json = JSON.parse(resultText);
                if (json.title && json.content) {
                    setTranslatedData({ title: json.title, content: json.content });
                    showToast(`Translated to ${targetLangName}`, "success");
                } else {
                    throw new Error("Invalid response format");
                }
            } else {
                throw new Error("Empty response");
            }

        } catch (error: any) {
            console.error("Translation failed:", error);
            showToast("Translation failed. Please try again.", "error");
        } finally {
            setIsTranslating(false);
        }
    };

    const handleShowOriginal = () => {
        setTranslatedData(null);
        stopAudio(); // Stop audio when switching back
    };

    // --- Audio Playback Logic ---
    const stopAudio = () => {
        if (audioSourceRef.current) {
            audioSourceRef.current.stop();
            audioSourceRef.current = null;
        }
        if (audioContextRef.current) {
            audioContextRef.current.close();
            audioContextRef.current = null;
        }
        setIsPlayingAudio(false);
    };

    const handleReadAloud = async () => {
        if (isPlayingAudio) {
            stopAudio();
            return;
        }

        if (!post) return;

        setIsGeneratingAudio(true);
        
        try {
            // Determine text source (original or translated)
            const titleToRead = translatedData ? translatedData.title : post.title;
            const contentToRead = translatedData ? translatedData.content : post.content;
            
            // Basic HTML strip for reading
            const plainTextContent = contentToRead.replace(/<[^>]+>/g, ' ');
            const textToRead = `${titleToRead}. ${plainTextContent}`;

            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            
            // Using the TTS model
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash-preview-tts",
                contents: {
                    parts: [{ text: textToRead }]
                },
                config: {
                    responseModalities: ['AUDIO'],
                    speechConfig: {
                        voiceConfig: {
                            prebuiltVoiceConfig: { voiceName: 'Kore' },
                        },
                    },
                },
            });

            const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
            
            if (base64Audio) {
                // Initialize Web Audio API context
                const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
                const ctx = new AudioContextClass({ sampleRate: 24000 });
                audioContextRef.current = ctx;

                const audioBuffer = await decodeAudioData(
                    decode(base64Audio),
                    ctx,
                    24000,
                    1
                );

                const source = ctx.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(ctx.destination);
                
                source.onended = () => {
                    setIsPlayingAudio(false);
                    setIsGeneratingAudio(false);
                };
                
                audioSourceRef.current = source;
                source.start();
                setIsPlayingAudio(true);
            } else {
                throw new Error("No audio data returned");
            }

        } catch (error: any) {
            console.error("TTS Error:", error);
            showToast("Failed to generate audio.", "error");
        } finally {
            setIsGeneratingAudio(false);
        }
    };


    const timeAgo = (date: Date | null) => {
        if (!date) return 'N/A';
        const now = new Date();
        const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + " years ago";
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + " months ago";
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + " days ago";
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + " hours ago";
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + " minutes ago";
        return Math.floor(seconds) + " seconds ago";
    };

    if (loading) {
        return <SkeletonPostDetail />;
    }

    if (error) {
        return <div className="flex items-center justify-center h-screen bg-transparent"><p className="text-red-500">{error}</p></div>;
    }
    
    if (!post) {
        return <div className="flex items-center justify-center h-screen bg-transparent"><p>Post not found.</p></div>;
    }

    const isCurrentUserPost = currentUser && currentUser.uid === post.authorId;
    const isAdmin = currentUser?.role === 'admin';
    const authorName = isCurrentUserPost ? currentUser.name : post.authorName;
    const authorProfilePicUrl = isCurrentUserPost ? currentUser.profilePicUrl : post.authorProfilePicUrl;

    // Determine what title and content to show (Original vs Translated)
    const displayTitle = translatedData ? translatedData.title : post.title;
    const displayContent = translatedData ? translatedData.content : post.content;

    return (
        <div className="flex flex-col h-full bg-transparent">
            <Header 
                title={t('post')} 
                showBackButton 
                onBack={onBack} 
                currentUser={currentUser}
                onProfileClick={() => onNavigate(View.User)}
                onLogin={onLogin}
                showSettingsButton
                onSettings={() => onNavigate(View.Settings)}
            />
            <main className="flex-grow overflow-y-auto pb-20 md:pb-10">
                <div className="w-full max-w-7xl mx-auto md:px-4 lg:px-8 py-0 md:py-6">
                    
                    {/* 1. Main Article Section */}
                    <div className="glass-card my-0 md:my-4 overflow-hidden rounded-none md:rounded-2xl shadow-sm md:shadow-xl border-x-0 md:border border-gray-100 bg-white mb-8">
                         <div className="px-4 py-3 md:px-6 md:py-4 flex items-center gap-3 border-b border-gray-100 bg-white/80 backdrop-blur-sm sticky top-0 z-10">
                            <img onClick={() => onViewUser(post.authorId)} src={authorProfilePicUrl} alt={authorName} className="w-10 h-10 rounded-full object-cover cursor-pointer ring-2 ring-gray-100" />
                            <div className="flex-grow">
                                <p onClick={() => onViewUser(post.authorId)} className="font-bold text-gray-800 cursor-pointer hover:text-blue-600">{authorName}</p>
                                <p className="text-xs text-gray-500">{timeAgo(post.createdAt)}</p>
                            </div>
                            
                            <div className="flex items-center gap-2">
                                {(!currentUser || currentUser.uid !== post.authorId) && (
                                    <button onClick={handleFollowToggle} className={`px-4 py-1.5 text-sm font-semibold rounded-full transition-colors ${isFollowing ? 'bg-gray-100 text-gray-700 hover:bg-gray-200' : 'gradient-button text-white shadow-md hover:shadow-lg'}`}>
                                        {isFollowing ? t('following') : t('follow')}
                                    </button>
                                )}
                            </div>
                        </div>
                        
                        {post.thumbnailUrl && (
                            <div className="w-full aspect-video md:max-h-[75vh] overflow-hidden bg-gray-100 relative">
                                <img src={post.thumbnailUrl} alt={post.title} className="w-full h-full object-cover" />
                            </div>
                        )}

                        <div className="p-5 md:p-8 lg:p-10">
                            <div className="w-full">
                                {/* Category & Date Context */}
                                <div className="flex items-center gap-3 mb-4 text-sm flex-wrap">
                                     <span className="bg-red-100 text-red-700 px-2 py-1 rounded font-bold uppercase text-xs tracking-wide">{post.category}</span>
                                     <span className="text-gray-500 flex items-center gap-1 font-medium">
                                        <span className="material-symbols-outlined text-[16px]">calendar_today</span>
                                        {post.createdAt ? new Date(post.createdAt).toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' }) : ''}
                                     </span>

                                     {/* Translate Button & Dropdown */}
                                    <div className="relative ml-2" ref={translateMenuRef}>
                                        {isTranslating ? (
                                            <div className="w-8 h-8 flex items-center justify-center bg-blue-50 rounded-full">
                                                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                                            </div>
                                        ) : translatedData ? (
                                            <button 
                                                onClick={handleShowOriginal}
                                                className="px-3 py-1 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-full transition-colors flex items-center gap-1"
                                            >
                                                <span className="material-symbols-outlined text-sm">undo</span>
                                                Original
                                            </button>
                                        ) : (
                                            <button 
                                                onClick={() => setShowTranslateMenu(!showTranslateMenu)}
                                                className="p-1.5 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors flex items-center gap-1"
                                                title="Translate Post"
                                            >
                                                <span className="material-symbols-outlined text-lg">g_translate</span>
                                            </button>
                                        )}

                                        {/* Dropdown Menu */}
                                        {showTranslateMenu && !isTranslating && (
                                            <div className="absolute left-0 top-full mt-2 w-48 bg-white/95 backdrop-blur-xl border border-white/20 shadow-2xl rounded-xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200 max-h-64 overflow-y-auto scrollbar-hide ring-1 ring-black/5">
                                                <div className="p-2 bg-gray-50 border-b border-gray-100 text-xs font-bold text-gray-500 uppercase tracking-wider text-center sticky top-0">
                                                    Select Language
                                                </div>
                                                {languages.map((lang) => (
                                                    <button
                                                        key={lang.code}
                                                        onClick={() => handleTranslate(lang.nativeName)}
                                                        className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-700 transition-colors flex items-center justify-between border-b border-gray-50 last:border-none"
                                                    >
                                                        <span>{lang.nativeName}</span>
                                                        <span className="text-xs text-gray-400">{lang.name}</span>
                                                    </button>
                                                ))}
                                            </div>
                                        )}
                                    </div>

                                    {/* Read Aloud Button */}
                                    <button
                                        onClick={handleReadAloud}
                                        className={`ml-1 p-1.5 rounded-full transition-colors flex items-center gap-1 ${isPlayingAudio ? 'text-red-600 bg-red-50 hover:bg-red-100' : 'text-gray-500 hover:text-blue-600 hover:bg-blue-50'}`}
                                        title={isPlayingAudio ? "Stop Reading" : "Read Aloud"}
                                        disabled={isGeneratingAudio}
                                    >
                                        {isGeneratingAudio ? (
                                            <div className="w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
                                        ) : (
                                            <span className="material-symbols-outlined text-lg">
                                                {isPlayingAudio ? 'stop_circle' : 'volume_up'}
                                            </span>
                                        )}
                                    </button>
                                </div>

                                <h1 className="text-2xl sm:text-3xl md:text-4xl font-extrabold text-gray-900 leading-normal md:leading-relaxed mb-6 tracking-tight break-words">
                                    {displayTitle}
                                </h1>
                                
                                <div className="prose prose-lg md:prose-xl max-w-none text-gray-700 leading-relaxed prose-headings:text-gray-900 prose-a:text-blue-600 prose-img:rounded-xl">
                                    <div dangerouslySetInnerHTML={{ __html: displayContent }} />
                                </div>
                            </div>
                        </div>

                        <div className="px-5 py-4 md:px-10 bg-gray-50 border-t border-gray-200 flex justify-between items-center text-gray-500">
                           <div className="flex items-center gap-6">
                                <div className="flex items-center gap-2" title="Views">
                                    <span className="material-symbols-outlined text-2xl">visibility</span>
                                    <span className="text-base font-medium">{post.viewCount || 0}</span>
                                </div>
                                <button 
                                    onClick={handleLike} 
                                    className={`flex items-center gap-2 transition-all active:scale-90 p-2 rounded-lg ${isLiked ? 'text-red-600' : 'hover:text-red-500'}`}
                                >
                                    <span 
                                        className={`material-symbols-outlined text-2xl transition-transform ${isLiked ? 'scale-110' : ''}`} 
                                        style={{ fontVariationSettings: `'FILL' ${isLiked ? 1 : 0}`}}
                                    >
                                        favorite
                                    </span>
                                    <span className="text-base font-medium">{likeCount}</span>
                                </button>
                                <div className="flex items-center gap-2">
                                    <span className="material-symbols-outlined text-2xl">chat_bubble</span>
                                    <span className="text-base font-medium">{comments.length}</span>
                                </div>
                                <button onClick={handleShare} className="flex items-center gap-2 text-green-600 hover:text-green-700 transition-colors p-2 rounded-lg" title="Share on WhatsApp">
                                    <i className="fa-brands fa-whatsapp text-2xl"></i>
                                    <span className="text-base font-medium">{post.shareCount || 0}</span>
                                </button>
                            </div>
                             <div className="relative">
                                <button onClick={() => setIsMenuOpen(v => !v)} className="p-2 rounded-full hover:bg-gray-200 transition-colors">
                                    <span className="material-symbols-outlined text-xl">more_vert</span>
                                </button>
                                {isMenuOpen && (
                                    <div className="absolute bottom-full right-0 mb-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 z-20 overflow-hidden ring-1 ring-black/5">
                                        {(isCurrentUserPost || isAdmin) && (
                                            <>
                                                <button 
                                                    onClick={() => { setIsMenuOpen(false); onEditPost(post.id); }} 
                                                    className="flex items-center gap-3 w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                                >
                                                    <span className="material-symbols-outlined text-lg">edit</span>
                                                    {t('edit')}
                                                </button>
                                                <button 
                                                    onClick={() => { setIsMenuOpen(false); setIsDeletePostModalOpen(true); }} 
                                                    className="flex items-center gap-3 w-full text-left px-4 py-3 text-sm text-red-600 hover:bg-red-50 transition-colors"
                                                >
                                                    <span className="material-symbols-outlined text-lg">delete</span>
                                                    {t('delete')}
                                                </button>
                                                <div className="border-b border-gray-100 my-1"></div>
                                            </>
                                        )}
                                        <button 
                                            onClick={() => {
                                                setIsMenuOpen(false);
                                                handleReport();
                                            }} 
                                            className="flex items-center gap-3 w-full text-left px-4 py-3 text-sm text-gray-700 hover:bg-red-50 hover:text-red-600 transition-colors"
                                        >
                                            <span className="material-symbols-outlined text-lg">flag</span>
                                            {t('report')}
                                        </button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* Insert Ad Banner Here */}
                    <AdBanner slotType="post" className="mb-8" />

                    {/* 2. Related Stories Section (Below Article) */}
                    {relatedPosts.length > 0 && (
                        <div className="mb-12 px-4 md:px-0">
                            <h2 className="text-2xl font-bold mb-6 text-gray-900 flex items-center gap-2">
                                <span className="w-1 h-8 bg-red-600 rounded-full"></span>
                                Related Stories
                            </h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                                {relatedPosts.map(relatedPost => (
                                    <div key={relatedPost.id} onClick={() => onViewPost(relatedPost.id)} className="glass-card overflow-hidden cursor-pointer group hover:shadow-lg transition-all duration-300 border border-gray-100 bg-white h-full flex flex-col">
                                         <div className="w-full h-48 overflow-hidden relative">
                                            <img 
                                                src={relatedPost.thumbnailUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${encodeURIComponent(relatedPost.title)}`} 
                                                alt={relatedPost.title}
                                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                                            />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                                         </div>
                                         <div className="p-4 flex-grow flex flex-col">
                                             <div className="flex items-center gap-2 mb-2">
                                                 <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-[10px] uppercase font-bold rounded-md tracking-wider">
                                                     {relatedPost.category}
                                                 </span>
                                                 <span className="text-xs text-gray-400">• {timeAgo(relatedPost.createdAt)}</span>
                                             </div>
                                             <h3 className="font-bold text-lg text-gray-800 leading-snug line-clamp-2 group-hover:text-red-600 transition-colors mb-2">
                                                 {relatedPost.title}
                                             </h3>
                                             <div className="mt-auto pt-3 border-t border-gray-50 flex items-center justify-between text-xs text-gray-500">
                                                 <span>By {relatedPost.authorName}</span>
                                                 <div className="flex items-center gap-1">
                                                     <span className="material-symbols-outlined text-[14px]">visibility</span>
                                                     {relatedPost.viewCount}
                                                 </div>
                                             </div>
                                         </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}

                    {/* 3. Comments Section (Bottom) */}
                    <div className="mb-12 px-4 md:px-0">
                         <div className="glass-card p-6 md:p-8 bg-white border border-gray-100">
                            <h2 className="text-xl md:text-2xl font-bold mb-6 text-gray-900 flex items-center gap-2 border-b border-gray-100 pb-4">
                                <span className="material-symbols-outlined text-blue-600 text-3xl">forum</span>
                                Comments ({comments.length})
                            </h2>
                            
                            {currentUser && (
                                 <form onSubmit={handleCommentSubmit} className="mb-10 flex items-start gap-4">
                                    <img src={currentUser.profilePicUrl} alt="Your profile" className="w-10 h-10 rounded-full object-cover shadow-sm ring-2 ring-white flex-shrink-0" />
                                    <div className="flex-grow">
                                        <textarea
                                            value={newComment}
                                            onChange={e => setNewComment(e.target.value)}
                                            placeholder="Add a comment..."
                                            className="w-full p-4 border border-gray-200 bg-gray-50 rounded-xl text-gray-900 focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all outline-none resize-none text-base"
                                            rows={3}
                                        />
                                        <div className="mt-2 flex justify-end">
                                            <button 
                                                type="submit" 
                                                disabled={isSubmittingComment || !newComment.trim()}
                                                className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg shadow-sm disabled:opacity-50 transition-colors"
                                            >
                                                {isSubmittingComment ? 'Posting...' : 'Post Comment'}
                                            </button>
                                        </div>
                                    </div>
                                 </form>
                            )}

                            <div className="space-y-6">
                                {comments.length > 0 ? (
                                    comments.map(comment => (
                                        <CommentItem 
                                            key={comment.id}
                                            comment={comment}
                                            postId={postId}
                                            currentUser={currentUser}
                                            isPostAuthor={post.authorId === comment.authorId}
                                            isAdmin={isAdmin}
                                            onViewUser={onViewUser}
                                            onDelete={() => confirmDeleteComment(comment.id)}
                                            onLogin={onLogin}
                                            showToast={showToast}
                                        />
                                    ))
                                ) : (
                                    <div className="text-center py-8 text-gray-500">
                                        No comments yet. Be the first to share your thoughts!
                                    </div>
                                )}
                            </div>
                         </div>
                    </div>

                </div>
            </main>

            {/* Modals */}
            {isReportModalOpen && currentUser && (
                <ReportModal 
                    post={post} 
                    user={currentUser} 
                    onClose={() => setIsReportModalOpen(false)}
                    onSuccess={handleReportSuccess}
                />
            )}

            <ConfirmationModal
                isOpen={isDeletePostModalOpen}
                onClose={() => setIsDeletePostModalOpen(false)}
                onConfirm={handleDeletePost}
                title="Delete Post"
                message="Are you sure you want to delete this post? This action cannot be undone."
                confirmButtonText="Delete"
                confirmButtonColor="bg-red-600 hover:bg-red-700"
            />

            <ConfirmationModal
                isOpen={isDeleteCommentModalOpen}
                onClose={() => setIsDeleteCommentModalOpen(false)}
                onConfirm={handleDeleteComment}
                title="Delete Comment"
                message="Are you sure you want to delete this comment?"
                confirmButtonText="Delete"
                confirmButtonColor="bg-red-600 hover:bg-red-700"
            />
        </div>
    );
};

export default PostDetailPage;
