
import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';
import { v4 as uuidv4 } from 'uuid';

type ToastType = 'success' | 'error' | 'info';

interface Toast {
  id: string;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  showToast: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const showToast = useCallback((message: string, type: ToastType = 'info') => {
    const id = uuidv4();
    setToasts((prev) => [...prev, { id, message, type }]);

    // Auto-dismiss after 3 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3000);
  }, []);

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-[60] flex flex-col gap-2 w-full max-w-sm px-4 pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`
              pointer-events-auto flex items-center p-4 mb-2 rounded-xl shadow-lg border backdrop-blur-md transition-all duration-500 animate-in slide-in-from-top-5 fade-in
              ${toast.type === 'success' ? 'bg-green-50/90 border-green-200 text-green-800' : ''}
              ${toast.type === 'error' ? 'bg-red-50/90 border-red-200 text-red-800' : ''}
              ${toast.type === 'info' ? 'bg-blue-50/90 border-blue-200 text-blue-800' : ''}
            `}
          >
            <div className={`
                flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mr-3
                ${toast.type === 'success' ? 'bg-green-100 text-green-600' : ''}
                ${toast.type === 'error' ? 'bg-red-100 text-red-600' : ''}
                ${toast.type === 'info' ? 'bg-blue-100 text-blue-600' : ''}
            `}>
                <span className="material-symbols-outlined text-lg">
                    {toast.type === 'success' && 'check_circle'}
                    {toast.type === 'error' && 'error'}
                    {toast.type === 'info' && 'info'}
                </span>
            </div>
            <div className="flex-grow text-sm font-medium">{toast.message}</div>
            <button 
                onClick={() => removeToast(toast.id)}
                className="ml-2 text-gray-400 hover:text-gray-600 transition-colors"
            >
                <span className="material-symbols-outlined text-sm">close</span>
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};
